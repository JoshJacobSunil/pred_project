from flask import Flask, render_template, request
import pickle
import numpy as np

application = Flask(__name__)
model = pickle.load(open("model.pkl", "rb"))

@application.route('/')
def index():
    return render_template('index.html')

@application.route('/result', methods=['POST'])
def result():
    data = [float(i) for i in request.form.values()]
    data = np.array(data).reshape(1, -1)
    output = model.predict(data)[0]
    status = "🟥 Risk Detected" if output == 1 else "🟩 No Risk"
    return render_template('index.html', prediction=status)

if __name__ == '__main__':
    application.run(debug=True)
